import Taro from '@tarojs/taro';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/index';
import { View, Button } from '@tarojs/components';
const Index = () => {
  return (
    <View>
      <Button
        plain
        type="primary"
        onClick={() =>
          Taro.navigateTo({
            url: '/pages/index/index',
          })
        }>
        跳转1
      </Button>
      <BrowserRouter>
        <Routes>
          <Route path="/home" element={<Home />}></Route>
        </Routes>
      </BrowserRouter>
    </View>
  );
};

export default Index;
