npm run dev:weapp 启动微信小程序
npm run dev:qywx 启动企业微信小程序

npm run dev:swan 启动百度小程序
npm run dev:alipay 启动支付宝小程序
npm run dev:tt 启动抖音小程序
npm run dev:h5 启动 h5 项目
npm run dev:rn 启动 rn 项目
npm run dev:qq 启动 qq 小程序
npm run dev:jd 启动京东小程序

目录配置
config ---taro 配置
src ---业务代码入口
