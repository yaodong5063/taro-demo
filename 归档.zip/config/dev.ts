import type { UserConfigExport } from "@tarojs/cli";

export default {
  logger: {
    quiet: true,
    stats: true,
  },
  mini: {},
  h5: {},
} satisfies UserConfigExport;
