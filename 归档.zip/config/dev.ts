export default {
  logger: {
    quiet: true,
    stats: true,
  },
  mini: {},
  h5: {},
};
